const { handler } = require('./src/handlers/createEvent');

exports.handler = handler;
