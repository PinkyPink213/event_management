const { createEvent } = require('../services/eventService');
const { response } = require('../utils/response');

exports.handler = async (event) => {
	try {
		const body = JSON.parse(event.body);
		const result = await createEvent(body);
		return response(201, result);
	} catch (err) {
		return response(400, { error: err.message });
	}
};
