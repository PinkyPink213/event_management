const { createEvent, registerEvent } = require('../src/services/eventService');

jest.mock('../src/repositories/eventRepository', () => ({
	createEvent: jest.fn(),
	getEventById: jest.fn(),
	registerUser: jest.fn(),
	isAlreadyRegistered: jest.fn(),
	incrementCount: jest.fn(),
}));

const repo = require('../src/repositories/eventRepository');

describe('Event Service', () => {
	beforeEach(() => {
		jest.clearAllMocks();
	});

	test('createEvent should create event successfully', async () => {
		const mockEvent = { name: 'Test Event', capacity: 10 };
		repo.createEvent.mockResolvedValue({ ...mockEvent, id: '1' });

		const result = await createEvent(mockEvent);

		expect(result.name).toBe('Test Event');
		expect(repo.createEvent).toHaveBeenCalled();
	});

	test('registerEvent should fail if event is full', async () => {
		repo.getEventById.mockResolvedValue({
			eventId: '1',
			capacity: 1,
			registeredCount: 1,
		});

		await expect(registerEvent('1', 'test@email.com')).rejects.toThrow(
			'Event is full'
		);
	});

	test('registerEvent success', async () => {
		repo.getEventById.mockResolvedValue({
			eventId: '1',
			capacity: 10,
			registeredCount: 5,
		});

		repo.isAlreadyRegistered.mockResolvedValue(false); // ⭐ สำคัญมาก
		repo.registerUser.mockResolvedValue();
		repo.incrementCount.mockResolvedValue();

		const result = await registerEvent('1', 'user@test.com');

		expect(result.message).toBe('Registered successfully');
	});
});
